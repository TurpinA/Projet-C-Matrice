#ifndef config_h
#define config_h

//Variables Preprocesseur

#define DEFAULT_SIZE_SOMMET 2


#endif
